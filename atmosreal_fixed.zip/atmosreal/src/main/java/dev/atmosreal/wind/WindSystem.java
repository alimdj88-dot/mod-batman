package dev.atmosreal.wind;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.config.AtmosRealConfig;
import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.engine.WeatherCell;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.LevelTickEvent;

@EventBusSubscriber(modid = AtmosReal.MOD_ID)
public class WindSystem {

    private static final int WIND_INTERVAL = 4; // every 4 ticks
    private static int ticker = 0;

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!AtmosRealConfig.windEnabled) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (++ticker % WIND_INTERVAL != 0) return;

        for (var player : level.players()) {
            WeatherCell cell = AtmosEngine.getOrCreate(level, player.blockPosition());
            float windSpeed = cell.windSpeed();
            if (windSpeed < 2.0f) continue;

            float mul = AtmosRealConfig.windForceMultiplier;
            double fx = cell.windX() / 20.0 * mul;
            double fz = cell.windZ() / 20.0 * mul;

            // Scale force by wind speed tiers
            double scale = windForceScale(windSpeed);
            Vec3 push = new Vec3(fx * scale, 0.0, fz * scale);

            if (!player.onGround()) {
                player.setDeltaMovement(player.getDeltaMovement().add(push));
            } else if (windSpeed > 18.0f) {
                // Strong ground wind knocks players off balance
                player.setDeltaMovement(player.getDeltaMovement().add(push.scale(0.3)));
            }

            // Apply same force to nearby non-player entities
            level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(24),
                e -> e != player && !e.isPassenger()
            ).forEach(entity -> {
                if (!entity.onGround()) {
                    entity.setDeltaMovement(entity.getDeltaMovement().add(push.scale(0.5)));
                }
            });
        }
    }

    private static double windForceScale(float windSpeed) {
        if (windSpeed > 30) return 2.5;
        if (windSpeed > 22) return 1.6;
        if (windSpeed > 14) return 0.9;
        if (windSpeed > 8)  return 0.4;
        return 0.15;
    }
}
