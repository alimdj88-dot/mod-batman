package dev.atmosreal.item;

import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.engine.WeatherCell;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class BarometerItem extends Item {

    public BarometerItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, 
                                                    net.minecraft.world.InteractionHand hand) {
        if (!level.isClientSide && level instanceof ServerLevel sl) {
            WeatherCell cell = AtmosEngine.getOrCreate(sl, player.blockPosition());

            player.sendSystemMessage(Component.literal(
                String.format("§b[Barometer] §fPressure: §e%.1f hPa  §fTemp: §e%.1f°C  " +
                              "§fHumidity: §e%.0f%%  §fWind: §e%.1f m/s @ %.0f°  §fWeather: §e%s",
                    cell.pressure(),
                    cell.temperature(),
                    cell.humidity() * 100f,
                    cell.windSpeed(),
                    cell.windDirection(),
                    cell.getWeatherType().name()
                )
            ));
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
