package dev.atmosreal;

import com.mojang.logging.LogUtils;
import dev.atmosreal.cloud.CloudSystem;
import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.network.ModNetwork;
import dev.atmosreal.registry.ModBlocks;
import dev.atmosreal.registry.ModItems;
import dev.atmosreal.registry.ModBlockEntities;
import dev.atmosreal.registry.ModEntities;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import org.slf4j.Logger;

/**
 * AtmosReal — main mod entry point.
 * Registers all DeferredRegister instances owned by the mod, wires the
 * atmospheric engine, the cloud system and the network channel into the
 * correct event buses and cleans up on server stop.
 */
@Mod(AtmosReal.MODID)
public final class AtmosReal {

    public static final String MODID = "atmosreal";
    public static final String MOD_ID = MODID;
    public static final Logger LOGGER = LogUtils.getLogger();

    private static AtmosEngine engine;
    private static CloudSystem cloudSystem;

    public AtmosReal(IEventBus modEventBus, ModContainer modContainer) {
        LOGGER.info("[AtmosReal] Initializing AtmosReal for Minecraft 1.26.3 / NeoForge 26.3.0.95");

        // ------------------------------------------------------------------
        // Register all DeferredRegister instances on the MOD event bus.
        // ------------------------------------------------------------------
        ModNetwork.REGISTER.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModEntities.ENTITY_TYPES.register(modEventBus);
        // Future DeferredRegisters (blocks, items, sounds, ...) follow the
        // same pattern:
        //   ModSounds.SOUNDS.register(modEventBus);
        //   ModBlocks.BLOCKS.register(modEventBus);

        // ------------------------------------------------------------------
        // Network channel registration (payload registrar).
        // ------------------------------------------------------------------
        ModNetwork.register();

        // ------------------------------------------------------------------
        // Server-side systems on the NeoForge game bus.
        // ------------------------------------------------------------------
        engine = new AtmosEngine();
        cloudSystem = new CloudSystem(engine);
        NeoForge.EVENT_BUS.register(engine);
        NeoForge.EVENT_BUS.register(cloudSystem);
        NeoForge.EVENT_BUS.register(new ServerLifecycleHandler());
        NeoForge.EVENT_BUS.register(new dev.atmosreal.tornado.TornadoSimulator());
        NeoForge.EVENT_BUS.register(new dev.atmosreal.weather.LightningSystem());

        LOGGER.info("[AtmosReal] Initialization complete.");
    }

    public static AtmosEngine getEngine() {
        return engine;
    }

    public static CloudSystem getCloudSystem() {
        return cloudSystem;
    }

    /** Internal handler for server shutdown cleanup. */
    public static final class ServerLifecycleHandler {

        @net.neoforged.bus.api.SubscribeEvent
        public void onServerStopping(ServerStoppingEvent event) {
            MinecraftServer server = event.getServer();
            AtmosEngine e = engine;
            if (e != null) {
                e.onServerStopping(server);
            }
        }
    }

    static {
        // Keep a compile-time reference so the import is meaningful.
        assert Level.class != null;
    }
}
