package dev.atmosreal.network;

import dev.atmosreal.engine.WeatherCell;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ChunkPos;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record AtmosDataPacket(int chunkX,int chunkZ,float temperature,float humidity,float pressure,float windU,float windV,float instability) implements CustomPacketPayload {
    public static final Type<AtmosDataPacket> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("atmosreal","atmos_data"));
    public static final StreamCodec<FriendlyByteBuf,AtmosDataPacket> STREAM_CODEC=StreamCodec.composite(
        ByteBufCodecs.VAR_INT,AtmosDataPacket::chunkX,ByteBufCodecs.VAR_INT,AtmosDataPacket::chunkZ,
        ByteBufCodecs.FLOAT,AtmosDataPacket::temperature,ByteBufCodecs.FLOAT,AtmosDataPacket::humidity,ByteBufCodecs.FLOAT,AtmosDataPacket::pressure,
        ByteBufCodecs.FLOAT,AtmosDataPacket::windU,ByteBufCodecs.FLOAT,AtmosDataPacket::windV,ByteBufCodecs.FLOAT,AtmosDataPacket::instability,AtmosDataPacket::new);
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
    public static AtmosDataPacket from(ChunkPos p,WeatherCell c){return new AtmosDataPacket(p.x,p.z,c.temperature(),c.humidity(),c.pressure(),c.windX(),c.windZ(),c.instabilityIndex());}
    public void handleClient(IPayloadContext context){context.enqueueWork(()->ClientWeatherCache.put(new ChunkPos(chunkX,chunkZ),new WeatherCell(temperature,humidity,pressure,windU,windV,instability)));}
}
