package dev.atmosreal.network;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;
/** Lightweight client cloud transition notification. */
public record CloudSystemPacket(int chunkX,int chunkZ,String cloudName) implements CustomPacketPayload {
 public static final Type<CloudSystemPacket> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("atmosreal","cloud_update"));
 public static final StreamCodec<FriendlyByteBuf,CloudSystemPacket> STREAM_CODEC=StreamCodec.composite(ByteBufCodecs.VAR_INT,CloudSystemPacket::chunkX,ByteBufCodecs.VAR_INT,CloudSystemPacket::chunkZ,ByteBufCodecs.STRING_UTF8,CloudSystemPacket::cloudName,CloudSystemPacket::new);
 @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
 public void handleClient(IPayloadContext ctx){ctx.enqueueWork(()->{});}
}
