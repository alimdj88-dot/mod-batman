package dev.atmosreal.network;
import dev.atmosreal.engine.WeatherCell;
import net.minecraft.world.level.ChunkPos;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/** Client-only atmospheric snapshot cache. */
public final class ClientWeatherCache { private static final Map<ChunkPos,WeatherCell> CELLS=new ConcurrentHashMap<>(); public ClientWeatherCache(){} public static void put(ChunkPos p,WeatherCell c){CELLS.put(p,c.sanitized());} public static WeatherCell get(ChunkPos p){return CELLS.getOrDefault(p,WeatherCell.DEFAULT);} public static Map<ChunkPos,WeatherCell> snapshot(){return Map.copyOf(CELLS);} public static void clear(){CELLS.clear();} }
