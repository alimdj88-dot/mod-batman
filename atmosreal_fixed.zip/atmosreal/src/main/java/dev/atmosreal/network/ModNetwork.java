package dev.atmosreal.network;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import java.util.UUID;

/** Payload registration and radius-limited server delivery. */
public final class ModNetwork {
    public static final EventBusRegistration REGISTER=new EventBusRegistration();
    private ModNetwork(){}
    public static final class EventBusRegistration { public void register(IEventBus bus){bus.addListener(ModNetwork::registerPayloads);} }
    public static void register() { /* Payload listener is attached by REGISTER to the mod event bus. */ }
    private static void registerPayloads(RegisterPayloadHandlersEvent event){
        PayloadRegistrar registrar=event.registrar("1");
        registrar.playToClient(AtmosDataPacket.TYPE,AtmosDataPacket.STREAM_CODEC,AtmosDataPacket::handleClient);
        registrar.playToClient(CloudSystemPacket.TYPE,CloudSystemPacket.STREAM_CODEC,CloudSystemPacket::handleClient);
    }
    public static void sendToAllNear(ServerLevel level,BlockPos pos,CustomPacketPayload payload){
        double radiusSq=256.0*256.0;
        for(ServerPlayer player:level.players()) if(player.blockPosition().distSqr(pos)<=radiusSq) player.connection.send(new net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket(payload));
    }
}
