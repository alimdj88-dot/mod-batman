package dev.atmosreal.config;

import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Common (server-authoritative) configuration for AtmosReal gameplay systems.
 * Registered as COMMON config in the mod constructor; static values are
 * refreshed on load/reload via the config event listeners below.
 */
public final class AtmosRealConfig {

    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    // ---- Hail ----
    public static final ModConfigSpec.BooleanValue HAIL_BREAKS_BLOCKS =
            BUILDER.comment("Allow baseball-sized hail to break glass blocks and panes.").define("hailBreaksBlocks", true);
    public static final ModConfigSpec.DoubleValue HAIL_DAMAGE_MULTIPLIER =
            BUILDER.comment("Multiplier applied to all hail damage amounts.").defineInRange("hailDamageMultiplier", 1.0, 0.0, 10.0);

    // ---- Lightning ----
    public static final ModConfigSpec.BooleanValue LIGHTNING_ENABLED =
            BUILDER.comment("Enable the AtmosReal lightning system (real LightningBolt entities).").define("lightningEnabled", true);
    public static final ModConfigSpec.DoubleValue LIGHTNING_RATE_MULTIPLIER =
            BUILDER.comment("Global strike-rate multiplier for the lightning system.").defineInRange("lightningRateMultiplier", 1.0, 0.0, 20.0);
    public static final ModConfigSpec.DoubleValue FULGURITE_CHANCE =
            BUILDER.comment("Chance (0.0-1.0) that a lightning strike melts sand into glass (fulgurite).").defineInRange("fulguriteChance", 0.35, 0.0, 1.0);

    // ---- Wind ----
    public static final ModConfigSpec.BooleanValue WIND_ENABLED =
            BUILDER.comment("Enable wind forces on entities.").define("windEnabled", true);
    public static final ModConfigSpec.DoubleValue WIND_FORCE_MULTIPLIER =
            BUILDER.comment("Global multiplier for wind force applied to entities.").defineInRange("windForceMultiplier", 1.0, 0.0, 10.0);

    // ---- Tornadoes ----
    public static final ModConfigSpec.BooleanValue TORNADOES_ENABLED =
            BUILDER.comment("Enable tornado spawning from tornadic weather cells.").define("tornadoesEnabled", true);
    public static final ModConfigSpec.BooleanValue TORNADO_GRIEFING =
            BUILDER.comment("Allow tornadoes to tear blocks from the terrain.").define("tornadoGriefing", true);
    public static final ModConfigSpec.IntValue MAX_TORNADOES_PER_LEVEL =
            BUILDER.comment("Maximum concurrently alive tornado entities per level.").defineInRange("maxTornadoesPerLevel", 3, 1, 32);
    public static final ModConfigSpec.IntValue TORNADO_BLOCKS_PER_TICK =
            BUILDER.comment("Maximum blocks a tornado may tear per tick (performance cap).").defineInRange("tornadoBlocksPerTick", 8, 0, 256);

    public static final ModConfigSpec SPEC = BUILDER.build();

    /** Live cached values (kept in sync by the event listeners). */
    public static volatile boolean hailBreaksBlocks = true;
    public static volatile double hailDamageMultiplier = 1.0;
    public static volatile boolean lightningEnabled = true;
    public static volatile double lightningRateMultiplier = 1.0;
    public static volatile double fulguriteChance = 0.35;
    public static volatile boolean windEnabled = true;
    public static volatile double windForceMultiplier = 1.0;
    public static volatile boolean tornadoesEnabled = true;
    public static volatile boolean tornadoGriefing = true;
    public static volatile int maxTornadoesPerLevel = 3;
    public static volatile int tornadoBlocksPerTick = 8;

    /** Copies spec values into the volatile cache. */
    public static void refresh() {
        hailBreaksBlocks = HAIL_BREAKS_BLOCKS.get();
        hailDamageMultiplier = HAIL_DAMAGE_MULTIPLIER.get();
        lightningEnabled = LIGHTNING_ENABLED.get();
        lightningRateMultiplier = LIGHTNING_RATE_MULTIPLIER.get();
        fulguriteChance = FULGURITE_CHANCE.get();
        windEnabled = WIND_ENABLED.get();
        windForceMultiplier = WIND_FORCE_MULTIPLIER.get();
        tornadoesEnabled = TORNADOES_ENABLED.get();
        tornadoGriefing = TORNADO_GRIEFING.get();
        maxTornadoesPerLevel = MAX_TORNADOES_PER_LEVEL.get();
        tornadoBlocksPerTick = TORNADO_BLOCKS_PER_TICK.get();
    }

    private AtmosRealConfig() {}
}
