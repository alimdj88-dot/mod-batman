package dev.atmosreal.cloud;

import dev.atmosreal.engine.WeatherCell;

/**
 * All cloud morphologies simulated by AtmosReal, grouped by altitude band.
 * minInstability is the 0-100 cell instabilityIndex needed to form the type.
 */
public enum CloudType {
    // ---- HIGH (cirrus family, 6000-13000 m) ----
    CIRRUS("Cirrus", 6000, 13000, 5, false, false, false, Group.HIGH),
    CIRRUS_UNCINUS("Cirrus Uncinus", 6000, 12000, 8, false, false, false, Group.HIGH),
    CIRRUS_FIBRATUS("Cirrus Fibratus", 6000, 13000, 10, false, false, false, Group.HIGH),
    CIRRUS_SPISSATUS("Cirrus Spissatus", 6000, 12000, 18, false, false, false, Group.HIGH),
    CIRRUS_CASTELLANUS("Cirrus Castellanus", 6000, 11000, 25, false, false, false, Group.HIGH),
    CIRRUS_FLOCCUS("Cirrus Floccus", 6000, 11000, 22, false, false, false, Group.HIGH),
    CIRRUS_DUPLICATUS("Cirrus Duplicatus", 7000, 13000, 12, false, false, false, Group.HIGH),
    CIRROCUMULUS("Cirrocumulus", 6000, 12000, 15, false, false, false, Group.HIGH),
    CIRROSTRATUS("Cirrostratus", 6000, 13000, 12, false, false, false, Group.HIGH),

    // ---- MID (alto family, 2000-6000 m) ----
    ALTOCUMULUS("Altocumulus", 2000, 6000, 20, false, false, false, Group.MID),
    ALTOCUMULUS_CASTELLANUS("Altocumulus Castellanus", 2000, 6000, 40, false, false, false, Group.MID),
    ALTOCUMULUS_LENTICULARIS("Altocumulus Lenticularis", 2500, 6000, 18, false, false, false, Group.MID),
    ALTOCUMULUS_FLOCCUS("Altocumulus Floccus", 2000, 5500, 30, false, false, false, Group.MID),
    ALTOCUMULUS_STRATIFORMIS("Altocumulus Stratiformis", 2000, 6000, 22, false, false, false, Group.MID),
    ALTOSTRATUS("Altostratus", 2000, 6000, 30, true, false, false, Group.MID),
    ALTOSTRATUS_OPACUS("Altostratus Opacus", 2000, 6000, 38, true, false, false, Group.MID),
    ALTOSTRATUS_TRANSLUCIDUS("Altostratus Translucidus", 2000, 6000, 30, true, false, false, Group.MID),
    NIMBOSTRATUS("Nimbostratus", 800, 5500, 55, true, false, false, Group.MID),

    // ---- LOW (stratus family, 0-2000 m) ----
    STRATUS("Stratus", 0, 2000, 15, false, false, false, Group.LOW),
    STRATUS_NEBULOSUS("Stratus Nebulosus", 0, 1500, 15, false, false, false, Group.LOW),
    STRATUS_FRACTUS("Stratus Fractus", 0, 1200, 25, false, false, false, Group.LOW),
    STRATOCUMULUS("Stratocumulus", 300, 2000, 25, true, false, false, Group.LOW),
    STRATOCUMULUS_UNDULATUS("Stratocumulus Undulatus", 300, 2000, 28, true, false, false, Group.LOW),
    STRATOCUMULUS_CUMULOGENITUS("Stratocumulus Cumulogenitus", 300, 2000, 32, true, false, false, Group.LOW),
    STRATOCUMULUS_PRAECIPITATIO("Stratocumulus Praecipitatio", 300, 2000, 40, true, false, false, Group.LOW),
    CUMULUS("Cumulus", 300, 2000, 30, false, false, false, Group.LOW),
    CUMULUS_HUMILIS("Cumulus Humilis", 300, 1800, 20, false, false, false, Group.LOW),
    CUMULUS_MEDIOCRIS("Cumulus Mediocris", 400, 2200, 35, false, false, false, Group.LOW),
    CUMULUS_FRACTUS("Cumulus Fractus", 200, 1500, 28, false, false, false, Group.LOW),

    // ---- VERTICAL (congestus / cumulonimbus family) ----
    CUMULUS_CONGESTUS("Cumulus Congestus", 500, 6000, 55, true, false, false, Group.VERTICAL),
    CUMULONIMBUS("Cumulonimbus", 500, 12000, 70, true, true, false, Group.VERTICAL),
    CUMULONIMBUS_CALVUS("Cumulonimbus Calvus", 500, 11000, 72, true, true, false, Group.VERTICAL),
    CUMULONIMBUS_CAPILLATUS("Cumulonimbus Capillatus", 500, 13000, 78, true, true, false, Group.VERTICAL),
    CUMULONIMBUS_INCOGNITUS("Cumulonimbus Incognitus", 500, 13000, 88, true, true, true, Group.VERTICAL),
    CUMULONIMBUS_MAMMATUS("Cumulonimbus Mammatus", 4000, 10000, 82, true, true, false, Group.VERTICAL),
    CUMULONIMBUS_PILEUS("Cumulonimbus Pileus", 500, 12000, 80, true, true, false, Group.VERTICAL),
    SUPERCELL("Supercell", 500, 14000, 92, true, true, true, Group.VERTICAL),
    WALL_CLOUD("Wall Cloud", 300, 2500, 86, true, true, true, Group.VERTICAL),
    SHELF_CLOUD("Shelf Cloud", 300, 3000, 84, true, true, false, Group.VERTICAL),
    ROLL_CLOUD("Roll Cloud", 300, 2000, 78, false, false, false, Group.VERTICAL),

    // ---- SPECIAL (rare / extreme phenomena) ----
    FUNNEL_CLOUD("Funnel Cloud", 100, 1200, 94, false, false, true, Group.SPECIAL),
    TORNADO_WALL("Tornado Wall Cloud", 100, 1500, 97, true, true, true, Group.SPECIAL),
    TOWERING_CUMULUS("Towering Cumulus", 600, 8000, 60, true, false, false, Group.SPECIAL),
    PYROCUMULUS("Pyrocumulus", 500, 7000, 65, false, false, false, Group.SPECIAL),
    HOMOGENITUS("Homogenitus", 500, 6000, 10, false, false, false, Group.SPECIAL),
    NOCTILUCENT("Noctilucent", 75000, 85000, 3, false, false, false, Group.SPECIAL),
    PEARL("Nacreous (Mother-of-Pearl)", 15000, 25000, 2, false, false, false, Group.SPECIAL),
    CLEAR("Clear Sky", 0, 0, 0, false, false, false, Group.LOW);

    public enum Group { HIGH, MID, LOW, VERTICAL, SPECIAL }

    public final String displayName;
    public final int minAltitude;
    public final int maxAltitude;
    public final float minInstability;
    public final boolean producesPrecipitation;
    public final boolean producesLightning;
    public final boolean producesTornado;
    public final Group group;

    CloudType(String displayName, int minAltitude, int maxAltitude, float minInstability,
              boolean producesPrecipitation, boolean producesLightning, boolean producesTornado, Group group) {
        this.displayName = displayName;
        this.minAltitude = minAltitude;
        this.maxAltitude = maxAltitude;
        this.minInstability = minInstability;
        this.producesPrecipitation = producesPrecipitation;
        this.producesLightning = producesLightning;
        this.producesTornado = producesTornado;
        this.group = group;
    }

    public String translationKey() {
        return "cloudtype.atmosreal." + name().toLowerCase(java.util.Locale.ROOT);
    }

    /** Picks the highest-severity cloud type the cell can currently sustain. */
    public static CloudType forCell(WeatherCell cell) {
        float inst = cell.instabilityIndex();
        float humidity = cell.humidity();
        float temp = cell.temperature();
        CloudType best = CLEAR;
        for (CloudType type : values()) {
            if (type == CLEAR) continue;
            if (inst < type.minInstability) continue;
            if (type.producesPrecipitation && humidity < 65.0F) continue;
            if (type == NOCTILUCENT && (temp > -20.0F || humidity > 30.0F)) continue;
            if (type == PEARL && temp > -40.0F) continue;
            if (type.group == Group.SPECIAL) continue; // specials form only via CloudSystem events
            if (best == CLEAR || type.minInstability >= best.minInstability) best = type;
        }
        if (best == CLEAR && humidity >= 30.0F && inst >= 2.0F) return CIRRUS;
        return best;
    }
}
