package dev.atmosreal.cloud;

import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.engine.WeatherCell;
import dev.atmosreal.network.CloudSystemPacket;
import dev.atmosreal.network.ModNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Lifecycle manager for per-chunk cloud types: forms, grows, decays and
 * transitions clouds from WeatherCell state, and drives precipitation FX.
 */
public final class CloudSystem {

    /** Lifecycle phase of a chunk's cloud. */
    public enum Phase { FORMING, MATURE, DECAYING }

    private final AtmosEngine engine;
    private final Map<ChunkPos, CloudType> activeCloudTypes = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Integer> lifeTicks = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Phase> phases = new ConcurrentHashMap<>();
    private final Random random = new Random();
    private static final int CLOUD_UPDATE_INTERVAL = 100; // 5 s

    public CloudSystem(AtmosEngine engine) {
        this.engine = engine;
        engine.setCloudSystem(this);
    }

    public CloudType getType(ChunkPos pos) { return activeCloudTypes.getOrDefault(pos, CloudType.CLEAR); }
    public Phase getPhase(ChunkPos pos) { return phases.getOrDefault(pos, Phase.FORMING); }
    public Map<ChunkPos, CloudType> getActiveCloudTypes() { return Map.copyOf(activeCloudTypes); }

    /** Called by the engine every simulation step with the fresh cell map. */
    public void update(ServerLevel level, Map<ChunkPos, WeatherCell> cells) {
        for (Map.Entry<ChunkPos, WeatherCell> entry : cells.entrySet()) {
            ChunkPos pos = entry.getKey();
            WeatherCell cell = entry.getValue();
            CloudType current = activeCloudTypes.get(pos);
            CloudType target = CloudType.forCell(cell);
            if (current == null) {
                activeCloudTypes.put(pos, target);
                phases.put(pos, Phase.FORMING);
                lifeTicks.put(pos, 0);
                broadcast(level, pos, target);
            } else if (target != current && target.minInstability > current.minInstability) {
                // only grow into stronger types via target selection; decay is time based
                activeCloudTypes.put(pos, target);
                broadcast(level, pos, target);
            }
            int life = lifeTicks.merge(pos, 1, Integer::sum);
            Phase phase = phases.getOrDefault(pos, Phase.FORMING);
            if (phase == Phase.FORMING && life > 200) phases.put(pos, Phase.MATURE);
            else if (phase == Phase.MATURE && cell.instabilityIndex() < current.minInstability * 0.8F) phases.put(pos, Phase.DECAYING);
            else if (phase == Phase.DECAYING && (life % 600 == 0)) {
                activeCloudTypes.put(pos, CloudType.forCell(cell));
                phases.put(pos, Phase.FORMING);
                lifeTicks.put(pos, 0);
                broadcast(level, pos, activeCloudTypes.get(pos));
            }
            if (life % CLOUD_UPDATE_INTERVAL == 0) precipitationTick(level, pos, getType(pos), cell);
        }
    }

    /** Spawns rain/snow/hail particles and lightning for one chunk. */
    public void precipitationTick(ServerLevel level, ChunkPos pos, CloudType type, WeatherCell cell) {
        if (!type.producesPrecipitation) return;
        float chance = cell.precipitationChance();
        if (random.nextFloat() > chance) return;
        int baseX = pos.getMinBlockX() + random.nextInt(16);
        int baseZ = pos.getMinBlockZ() + random.nextInt(16);
        int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, baseX, baseZ);
        BlockPos at = new BlockPos(baseX, surfaceY + 1, baseZ);

        if (cell.temperature() <= 0.0F) {
            // snow / blizzard
            level.sendParticles(ParticleTypes.SNOWFLAKE, baseX + 0.5, surfaceY + random.nextInt(8) + 2, baseZ + 0.5, 12, 3.0, 2.0, 3.0, 0.02);
        } else if (cell.instabilityIndex() > 80.0F && random.nextFloat() < 0.35F) {
            // hail
            level.sendParticles(ParticleTypes.FALLING_DRIPSTONE_WATER, baseX + 0.5, surfaceY + random.nextInt(6) + 3, baseZ + 0.5, 8, 2.0, 2.0, 2.0, 0.1);
        } else {
            // rain
            level.sendParticles(ParticleTypes.FALLING_WATER, baseX + 0.5, surfaceY + random.nextInt(8) + 2, baseZ + 0.5, 10, 3.0, 2.5, 3.0, 0.0);
        }
        if (type.producesLightning && random.nextFloat() < 0.05F) {
            level.setThunderLevel(Math.min(1.0F, level.getThunderLevel() + 0.2F));
            if (random.nextFloat() < 0.3F) {
                BlockPos strike = level.findLightningTargetAround(at);
                if (strike != null) {
                    net.minecraft.server.level.ServerPlayer nearest = null;
                    double best = Double.MAX_VALUE;
                    for (var p : level.players()) {
                        double d = p.blockPosition().distSqr(strike);
                        if (d < best) { best = d; nearest = p; }
                    }
                    if (nearest != null && best < 512 * 512) {
                        net.minecraft.network.protocol.game.ClientboundLightningBoltPacket bolt =
                                new net.minecraft.network.protocol.game.ClientboundLightningBoltPacket(
                                        net.minecraft.world.entity.EntityType.LIGHTNING_BOLT,
                                        net.minecraft.world.entity.EntityType.LIGHTNING_BOLT.create(level),
                                        new java.util.List.of(), strike.getX(), strike.getY(), strike.getZ(), false);
                        nearest.connection.send(bolt);
                    }
                }
            }
        }
    }

    private void broadcast(ServerLevel level, ChunkPos pos, CloudType type) {
        BlockPos center = new BlockPos(pos.getMiddleBlockX(), level.getMinBuildHeight() + 80, pos.getMiddleBlockZ());
        ModNetwork.sendToAllNear(level, center, new CloudSystemPacket(pos.x, pos.z, type.name()));
    }

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        // Periodic cleanup of dead chunk entries happens lazily on decay above.
    }
}
