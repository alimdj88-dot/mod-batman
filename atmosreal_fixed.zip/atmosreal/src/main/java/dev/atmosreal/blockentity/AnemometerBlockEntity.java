package dev.atmosreal.blockentity;

import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.engine.WeatherCell;
import dev.atmosreal.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class AnemometerBlockEntity extends BlockEntity {

    private float windSpeed;
    private float windDirection;
    private int timer = 0;

    public AnemometerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ANEMOMETER.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state,
                             AnemometerBlockEntity be) {
        if (!(level instanceof ServerLevel sl)) return;
        if (++be.timer < 10) return;
        be.timer = 0;

        WeatherCell cell = AtmosEngine.getOrCreate(sl, pos);
        be.windSpeed     = cell.windSpeed();
        be.windDirection = cell.windDirection();
        be.setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider r) {
        super.saveAdditional(tag, r);
        tag.putFloat("windSpeed", windSpeed);
        tag.putFloat("windDir",   windDirection);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider r) {
        super.loadAdditional(tag, r);
        windSpeed     = tag.getFloat("windSpeed");
        windDirection = tag.getFloat("windDir");
    }

    public float getWindSpeed()     { return windSpeed; }
    public float getWindDirection() { return windDirection; }
}
