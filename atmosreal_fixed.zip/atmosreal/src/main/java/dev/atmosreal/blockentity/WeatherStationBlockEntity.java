package dev.atmosreal.blockentity;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.engine.WeatherCell;
import dev.atmosreal.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class WeatherStationBlockEntity extends BlockEntity implements MenuProvider {

    // Cached readings updated every 20 ticks
    private float temperature;
    private float humidity;
    private float pressure;
    private float windSpeed;
    private float windDirection;
    private String weatherTypeName = "CLEAR";

    private int updateTimer = 0;

    public WeatherStationBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.WEATHER_STATION.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state,
                                   WeatherStationBlockEntity be) {
        if (!(level instanceof ServerLevel sl)) return;
        if (++be.updateTimer < 20) return;
        be.updateTimer = 0;

        WeatherCell cell = AtmosEngine.getOrCreate(sl, pos);
        be.temperature    = cell.temperature();
        be.humidity       = cell.humidity();
        be.pressure       = cell.pressure();
        be.windSpeed      = cell.windSpeed();
        be.windDirection  = cell.windDirection();
        be.weatherTypeName = cell.getWeatherType().name();
        be.setChanged();
    }

    public void openScreen(ServerPlayer player) {
        if (this.createMenu(0, player.getInventory(), player) != null) {
            player.openMenu(this);
        }
    }

    // ── NBT ──────────────────────────────────────────────────────────────

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putFloat("temperature", temperature);
        tag.putFloat("humidity",    humidity);
        tag.putFloat("pressure",    pressure);
        tag.putFloat("windSpeed",   windSpeed);
        tag.putFloat("windDir",     windDirection);
        tag.putString("weatherType", weatherTypeName);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        temperature    = tag.getFloat("temperature");
        humidity       = tag.getFloat("humidity");
        pressure       = tag.getFloat("pressure");
        windSpeed      = tag.getFloat("windSpeed");
        windDirection  = tag.getFloat("windDir");
        weatherTypeName = tag.getString("weatherType");
    }

    // ── MenuProvider ─────────────────────────────────────────────────────

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.atmosreal.weather_station");
    }

    @Override
    public @Nullable AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        // Simple data-only menu; screen reads data via block entity sync
        return null; // replaced with GUI in ClientSetup
    }

    // ── Accessors ─────────────────────────────────────────────────────────

    public float getTemperature()   { return temperature; }
    public float getHumidity()      { return humidity; }
    public float getPressure()      { return pressure; }
    public float getWindSpeed()     { return windSpeed; }
    public float getWindDirection() { return windDirection; }
    public String getWeatherTypeName() { return weatherTypeName; }
}
