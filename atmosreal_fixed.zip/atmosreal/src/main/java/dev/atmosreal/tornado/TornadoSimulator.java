package dev.atmosreal.tornado;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.config.AtmosRealConfig;
import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.engine.WeatherCell;
import dev.atmosreal.engine.WeatherType;
import dev.atmosreal.registry.ModEntities;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * TornadoSimulator — watches tornadic weather cells each second and spawns
 * {@link TornadoEntity} instances when instability + wind gating is met.
 * Respects {@link AtmosRealConfig#MAX_TORNADOES_PER_LEVEL} and deduplicates
 * spawns per chunk to prevent spam.
 */
public final class TornadoSimulator {

    private static final int TICK_RATE = 20;

    /** Minimum instability required before tornado consideration. */
    private static final float INSTABILITY_THRESHOLD = 80.0F;

    private final Random random = new Random();
    /** Chunk key -> tick of last spawn, prevents repeated spawns on same cell. */
    private final Map<String, Long> lastSpawnByChunk = new HashMap<>();

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        if (!AtmosRealConfig.tornadoesEnabled) return;
        if (event.getServer().getTickCount() % TICK_RATE != 0) return;
        AtmosEngine engine = AtmosReal.getEngine();
        if (engine == null) return;

        for (ServerLevel level : event.getServer().getAllLevels()) {
            long alive = countTornadoes(level);
            if (alive >= AtmosRealConfig.maxTornadoesPerLevel) continue;

            for (Map.Entry<ChunkPos, WeatherCell> e : engine.snapshot().entrySet()) {
                if (alive >= AtmosRealConfig.maxTornadoesPerLevel) break;
                ChunkPos pos = e.getKey();
                if (!level.getChunkSource().hasChunk(pos.x, pos.z)) continue;
                WeatherCell cell = e.getValue();
                WeatherType type = WeatherType.fromConditions(cell, cell.windSpeed(), false);
                if (!type.isTornadic()) continue;
                if (cell.instabilityIndex() < INSTABILITY_THRESHOLD) continue;
                if (cell.windSpeed() < WeatherType.TORNADO_MIN_WIND_SPEED) continue;

                String key = level.dimension().location() + ":" + pos.x + "," + pos.z;
                long now = event.getServer().getTickCount();
                Long last = lastSpawnByChunk.get(key);
                if (last != null && now - last < 20L * 60L * 5L) continue; // 5-minute cooldown

                // Probability scaling with instability beyond the threshold.
                double chance = (cell.instabilityIndex() - INSTABILITY_THRESHOLD) / 100.0 + 0.02;
                if (random.nextDouble() > chance) continue;

                EFScale rating = assignRating(cell);
                int x = pos.getMiddleBlockX();
                int z = pos.getMiddleBlockZ();
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);

                TornadoEntity tornado = new TornadoEntity(level, x + 0.5, y, z + 0.5, rating);
                level.addFreshEntity(tornado);
                lastSpawnByChunk.put(key, now);
                alive++;
            }
        }
    }

    /** Rates the tornado from instability + wind speed (EF scale). */
    private EFScale assignRating(WeatherCell cell) {
        float combined = cell.instabilityIndex() * 0.5F + cell.windSpeed() * 0.5F;
        // Map combined score (roughly 40..100) onto EF0..EF5.
        int idx = (int) ((combined - 45.0F) / 10.0F);
        idx = Math.max(0, Math.min(EFScale.values().length - 1, idx));
        return EFScale.values()[idx];
    }

    private long countTornadoes(ServerLevel level) {
        return level.getEntities(ModEntities.TORNADO.get(), t -> t.isAlive()).size();
    }

    /** Number of distinct spawn cooldowns tracked (diagnostics). */
    public int trackedCells() { return lastSpawnByChunk.size(); }
}
