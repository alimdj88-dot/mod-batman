package dev.atmosreal.tornado;

import java.util.Locale;

/**
 * EFScale — Enhanced Fujita scale for AtmosReal tornadoes.
 * Each rating defines wind speed ranges (m/s at 10 m), the maximum vanilla
 * block explosion resistance the funnel can tear, the destructive radius in
 * blocks, and a base lifetime in ticks.
 */
public enum EFScale {
    EF0(29f, 38f, 1.5f, 6f, 20f * 60f),
    EF1(38f, 49f, 3.0f, 10f, 20f * 90f),
    EF2(49f, 60f, 6.0f, 14f, 20f * 120f),
    EF3(60f, 74f, 12.0f, 18f, 20f * 150f),
    EF4(74f, 89f, 25.0f, 24f, 20f * 180f),
    EF5(89f, 110f, 60.0f, 32f, 20f * 240f);

    /** Maximum wind speed in m/s at 10 m height (upper bound). */
    public final float maxWindSpeed;
    /** Minimum wind speed in m/s (lower bound). */
    public final float minWindSpeed;
    /** Maximum vanilla block explosionResistance this EF rating can tear. */
    public final float blockResistanceThreshold;
    /** Destructive half-width of the funnel in blocks. */
    public final float radius;
    /** Base lifetime in ticks before self-despawn. */
    public final int lifetimeTicks;

    EFScale(float minWindSpeed, float maxWindSpeed, float blockResistanceThreshold,
            float radius, int lifetimeTicks) {
        this.minWindSpeed = minWindSpeed;
        this.maxWindSpeed = maxWindSpeed;
        this.blockResistanceThreshold = blockResistanceThreshold;
        this.radius = radius;
        this.lifetimeTicks = lifetimeTicks;
    }

    /** Mean wind speed of this rating, m/s. */
    public float meanWindSpeed() {
        return (minWindSpeed + maxWindSpeed) * 0.5f;
    }

    /** Rating whose range contains the given wind speed; EF0 below, EF5 above. */
    public static EFScale fromWindSpeed(float windSpeed) {
        for (EFScale ef : values()) {
            if (windSpeed <= ef.maxWindSpeed) return ef;
        }
        return EF5;
    }

    /** Uniform random pick between min and max wind speed of this rating. */
    public float randomWindSpeed(java.util.Random random) {
        return minWindSpeed + random.nextFloat() * (maxWindSpeed - minWindSpeed);
    }

    @Override
    public String toString() {
        return name().toUpperCase(Locale.ROOT);
    }
}
