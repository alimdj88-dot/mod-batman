package dev.atmosreal.tornado;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.config.AtmosRealConfig;
import dev.atmosreal.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageSources;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/**
 * TornadoEntity — non-solid server-driven vortex entity that travels with the
 * storm wind, tears blocks below its resistance threshold, damages and flings
 * entities, and despawns after its EF-scale lifetime.
 */
public class TornadoEntity extends Entity {

    private static final EntityDataAccessor<Integer> DATA_EF_RATING =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_SPIN =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.FLOAT);

    private EFScale efScale = EFScale.EF0;
    private int lifeTicks = 0;
    private int despawnTicks = -1;
    private final Random random = new Random();

    public TornadoEntity(EntityType<? extends TornadoEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.blocksBuilding = false;
    }

    /** Constructor matching {@link ModEntities#TORNADO} factory reference. */
    public TornadoEntity(Level level, double x, double y, double z, EFScale scale) {
        this(ModEntities.TORNADO.get(), level);
        this.moveTo(x, y, z, this.random.nextFloat() * 360.0F, 0.0F);
        this.setEfScale(scale);
        this.despawnTicks = scale.lifetimeTicks;
    }

    public EFScale getEfScale() { return efScale; }

    public void setEfScale(EFScale scale) {
        this.efScale = scale;
        this.entityData.set(DATA_EF_RATING, scale.ordinal());
    }

    /** Visual spin accumulator used by the client renderer. */
    public float getSpin() { return this.entityData.get(DATA_SPIN); }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_EF_RATING, EFScale.EF0.ordinal());
        builder.define(DATA_SPIN, 0.0F);
    }

    // ==================================================================
    // Tick logic
    // ==================================================================

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            spinClient();
            return;
        }
        if (!(level() instanceof ServerLevel server)) return;

        lifeTicks++;
        if (despawnTicks > 0 && lifeTicks >= despawnTicks) {
            discard();
            return;
        }

        moveWithWind();
        devBlocksWithBudget(server);
        affectEntities(server);
        spawnFunnelEffects(server);

        if (lifeTicks % 20 == 0) {
            server.playSound(null, blockPosition(), SoundEvents.WITHER_AMBIENT, SoundSource.WEATHER, 1.5F, 0.6F);
        }
    }

    private void spinClient() {
        entityData.set(DATA_SPIN, (entityData.get(DATA_SPIN) + 0.35F) % 360.0F);
        Vec3 base = position();
        for (int i = 0; i < 6; i++) {
            double ang = random.nextDouble() * Math.PI * 2;
            double r = 1.0 + random.nextDouble() * efScale.radius * 0.5;
            level().addParticle(ParticleTypes.POOF,
                    base.x + Math.cos(ang) * r,
                    base.y + random.nextDouble() * 12.0,
                    base.z + Math.sin(ang) * r, 0, 0.4, 0);
        }
    }

    /** Travels along the ground using the storm's wind vector as motion. */
    private void moveWithWind() {
        dev.atmosreal.engine.WeatherCell cell = AtmosReal.getEngine() != null
                ? AtmosReal.getEngine().getCell(new net.minecraft.world.level.ChunkPos(blockPosition()))
                : null;
        float wx = cell != null ? cell.windX() : 0.3f;
        float wz = cell != null ? cell.windZ() : 0.0f;
        double speed = Math.min(6.0, Math.sqrt(wx * wx + wz * wz) * 0.35) + 0.5;

        Vec3 dir = new Vec3(wx, 0, wz);
        if (dir.lengthSqr() < 1.0E-4) dir = new Vec3(1, 0, 0);
        dir = dir.normalize();

        Vec3 target = position().add(dir.scale(speed));
        int bx = (int) Math.floor(target.x);
        int bz = (int) Math.floor(target.z);
        int surface = level().getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz);
        setPos(target.x, surface, target.z);
        setDeltaMovement(dir.scale(speed));
    }

    /** Tears up to {@code tornadoBlocksPerTick} blocks within the EF radius. */
    private void devBlocksWithBudget(ServerLevel server) {
        if (!AtmosRealConfig.tornadoGriefing) return;
        int budget = AtmosRealConfig.tornadoBlocksPerTick;
        if (budget <= 0) return;

        int r = (int) Math.ceil(efScale.radius);
        BlockPos center = blockPosition();
        int torn = 0;
        for (int attempt = 0; attempt < budget * 4 && torn < budget; attempt++) {
            int dx = random.nextInt(r * 2 + 1) - r;
            int dz = random.nextInt(r * 2 + 1) - r;
            if (dx * dx + dz * dz > r * r) continue;
            BlockPos p = center.offset(dx, random.nextInt(3) - 1, dz);
            BlockState state = server.getBlockState(p);
            if (state.isAir() || state.is(Blocks.BEDROCK)) continue;
            if (state.getBlock().defaultDestroyTime() < 0) continue; // unbreakable
            if (state.getBlock().getExplosionResistance() > efScale.blockResistanceThreshold) continue;
            server.destroyBlock(p, true);
            torn++;
        }
    }

    /** Damages and flings living entities caught in the funnel. */
    private void affectEntities(ServerLevel server) {
        double r = efScale.radius;
        AABB box = getBoundingBox().inflate(r, 6.0, r);
        DamageSource src = server.damageSources().genericKill();
        for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, box)) {
            if (StormShelterCheck.isProtected(living)) continue;
            living.hurt(src, 4.0F + efScale.ordinal() * 2.5F);
            Vec3 swirl = new Vec3(
                    (living.getX() - getX()),
                    0.8 + random.nextDouble(),
                    (living.getZ() - getZ())).normalize();
            living.setDeltaMovement(swirl.scale(0.6 + efScale.ordinal() * 0.25));
            living.hurtMarked = true;
        }
    }

    private void spawnFunnelEffects(ServerLevel server) {
        server.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 2, getZ(), 20, efScale.radius * 0.4, 4.0, efScale.radius * 0.4, 0.02);
    }

    // ==================================================================
    // Persistence
    // ==================================================================

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.efScale = EFScale.values()[tag.getInt("EfRating")];
        this.lifeTicks = tag.getInt("LifeTicks");
        this.despawnTicks = tag.getInt("DespawnTicks");
        this.entityData.set(DATA_EF_RATING, this.efScale.ordinal());
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("EfRating", efScale.ordinal());
        tag.putInt("LifeTicks", lifeTicks);
        tag.putInt("DespawnTicks", despawnTicks);
    }

    @Override
    public boolean isPickable() { return false; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    protected boolean canAddPassenger(Entity passenger) { return false; }
}
