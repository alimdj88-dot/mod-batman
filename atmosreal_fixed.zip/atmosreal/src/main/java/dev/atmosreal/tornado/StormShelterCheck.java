package dev.atmosreal.tornado;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.phys.AABB;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * StormShelterCheck — shared helper consulted by WindSystem, TornadoSimulator
 * and precipitation handling before applying severe weather damage. A player
 * within {@link #PROTECTION_RADIUS} of a storm shelter block is protected.
 */
public final class StormShelterCheck {

    /** Protection radius in blocks around a shelter block. */
    public static final int PROTECTION_RADIUS = 16;

    /** BlockEntity type of StormShelterBlock (set at registration time). */
    private static volatile BlockEntityType<?> shelterBlockEntityType;

    /** Cached world -> set of shelter positions discovered per dimension. */
    private static final Map<String, java.util.Set<Long>> SHELTER_CACHE = new ConcurrentHashMap<>();

    private StormShelterCheck() {}

    /** Called by ModBlocks while registering the storm shelter BlockEntityType. */
    public static void setShelterBlockEntityType(BlockEntityType<?> type) {
        shelterBlockEntityType = type;
    }

    private static String key(Level level) {
        return level.dimension().location().toString();
    }

    /** True when the entity is within the protection radius of any shelter. */
    public static boolean isProtected(Entity entity) {
        return isProtected(entity.level(), entity.blockPosition());
    }

    /**
     * True when the position is within {@code radius} of a shelter, or
     * within {@link #PROTECTION_RADIUS} when {@code radius <= 0}.
     */
    public static boolean isProtected(Level level, BlockPos pos) {
        return nearestShelter(level, pos) >= 0;
    }

    /**
     * Square distance to the nearest shelter, or {@code -1} when none found
     * within {@link #PROTECTION_RADIUS}. Results are cached per level and
     * invalidated whenever a shelter block is added or removed.
     */
    public static double nearestShelter(Level level, BlockPos pos) {
        var shelters = SHELTER_CACHE.get(key(level));
        if (shelters == null) {
            shelters = java.util.Collections.newSetFromMap(new ConcurrentHashMap<>());
            SHELTER_CACHE.put(key(level), shelters);
        }
        if (shelters.isEmpty()) return -1;
        double bestSq = Double.MAX_VALUE;
        for (Long packed : shelters) {
            BlockPos p = BlockPos.of(packed);
            double d = p.distSqr(pos);
            if (d < bestSq) bestSq = d;
        }
        if (bestSq <= (double) (PROTECTION_RADIUS * PROTECTION_RADIUS)) return bestSq;
        return -1;
    }

    /** Reduced damage factor (1.0 = unprotected, 0.1 right next to shelter). */
    public static float damageFactor(Entity entity) {
        double d = nearestShelter(entity.level(), entity.blockPosition());
        if (d < 0) return 1.0F;
        double r2 = (double) PROTECTION_RADIUS * PROTECTION_RADIUS;
        // linear falloff from 0.1 at the shelter to 0.9 at the edge.
        return (float) Math.max(0.1, 0.1 + 0.8 * (d / r2));
    }

    // ------------------------------------------------------------------
    // Cache maintenance
    // ------------------------------------------------------------------

    public static void onShelterPlaced(Level level, BlockPos pos) {
        SHELTER_CACHE.computeIfAbsent(key(level), k -> java.util.Collections.newSetFromMap(new ConcurrentHashMap<>()))
                .add(pos.asLong());
    }

    public static void onShelterRemoved(Level level, BlockPos pos) {
        var shelters = SHELTER_CACHE.get(key(level));
        if (shelters != null) shelters.remove(pos.asLong());
    }

    /** Clears all cached shelters (server stop / dimension unload). */
    public static void clearCache() { SHELTER_CACHE.clear(); }
}
