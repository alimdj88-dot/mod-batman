package dev.atmosreal.engine;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.server.level.ServerLevel;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent atmospheric state, scoped to one dimension's SavedDataStorage. */
public final class AtmosEngineData extends SavedData {
    private static final String NAME="atmosreal_weather";
    private final Map<ChunkPos, WeatherCell> cells=new ConcurrentHashMap<>();
    private static final Factory<AtmosEngineData> FACTORY=new Factory<>(AtmosEngineData::create, AtmosEngineData::load, null);
    public static AtmosEngineData create(){return new AtmosEngineData();}
    public static AtmosEngineData load(CompoundTag tag){
        AtmosEngineData data=create(); ListTag list=tag.getList("cells", Tag.TAG_COMPOUND);
        for(int n=0;n<list.size();n++){ CompoundTag e=list.getCompound(n); ChunkPos p=new ChunkPos(e.getInt("x"),e.getInt("z"));
            data.cells.put(p,new WeatherCell(e.getFloat("temperature"),e.getFloat("humidity"),e.getFloat("pressure"),e.getFloat("windU"),e.getFloat("windV"),e.getFloat("instability")).sanitized()); }
        return data;
    }
    public static AtmosEngineData getOrCreate(ServerLevel level){return level.getDataStorage().computeIfAbsent(FACTORY,NAME);}
    public WeatherCell get(ChunkPos pos){return cells.get(pos);}
    public void put(ChunkPos pos,WeatherCell cell){cells.put(new ChunkPos(pos.x,pos.z),cell.sanitized());setDirty();}
    public Map<ChunkPos,WeatherCell> snapshot(){return Map.copyOf(cells);}
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries){
        ListTag list=new ListTag(); for(var entry:cells.entrySet()){WeatherCell c=entry.getValue(); CompoundTag e=new CompoundTag(); e.putInt("x",entry.getKey().x);e.putInt("z",entry.getKey().z);e.putFloat("temperature",c.temperature());e.putFloat("humidity",c.humidity());e.putFloat("pressure",c.pressure());e.putFloat("windU",c.windX());e.putFloat("windV",c.windZ());e.putFloat("instability",c.instabilityIndex());list.add(e);} tag.put("cells",list);return tag;
    }
}
