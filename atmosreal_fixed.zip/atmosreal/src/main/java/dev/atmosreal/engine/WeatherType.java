package dev.atmosreal.engine;

/**
 * WeatherType — the observable ground-level weather state derived from a
 * {@link WeatherCell}. Unlike {@link dev.atmosreal.cloud.CloudType} (cloud
 * morphology), this enum drives gameplay: precipitation, hail, wind forces,
 * lightning and tornado spawning.
 *
 * IMPORTANT: unbounded temperature limits use {@link Float#NEGATIVE_INFINITY}
 * / {@link Float#POSITIVE_INFINITY} — never Float.MIN_VALUE, which is a tiny
 * positive number and would break every sub-zero temperature check.
 */
public enum WeatherType {

    // ---- Fair weather ----
    CLEAR(0.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, false, false),
    PARTLY_CLOUDY(5.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, false, false),
    OVERCAST(20.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, false, false),
    VIRGA(35.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, true, false, false),

    // ---- Liquid rain ----
    LIGHT_RAIN(30.0F, 0.5F, Float.POSITIVE_INFINITY, true, false, false),
    MODERATE_RAIN(45.0F, 1.0F, Float.POSITIVE_INFINITY, true, false, false),
    HEAVY_RAIN(60.0F, 1.0F, Float.POSITIVE_INFINITY, true, false, false),
    TORRENTIAL_RAIN(70.0F, 2.0F, Float.POSITIVE_INFINITY, true, false, false),

    // ---- Mixed phase ----
    SLEET(50.0F, -3.0F, 3.0F, true, false, false),
    FREEZING_RAIN(50.0F, -6.0F, 0.0F, true, false, false),

    // ---- Snow ----
    LIGHT_SNOW(30.0F, Float.NEGATIVE_INFINITY, 0.0F, true, false, false),
    HEAVY_SNOW(55.0F, Float.NEGATIVE_INFINITY, 1.0F, true, false, false),
    BLIZZARD(65.0F, Float.NEGATIVE_INFINITY, 0.0F, true, true, false),

    // ---- Hail (damage tiers) ----
    HAIL_GRAUPEL(60.0F, -10.0F, 25.0F, true, false, false),
    HAIL_GOLF(75.0F, -10.0F, 30.0F, true, true, false),
    HAIL_BASEBALL(85.0F, -10.0F, 30.0F, true, true, false),

    // ---- Thunderstorms ----
    THUNDERSTORM(70.0F, 0.0F, Float.POSITIVE_INFINITY, true, true, false),
    SEVERE_THUNDERSTORM(82.0F, 0.0F, Float.POSITIVE_INFINITY, true, true, false),
    SUPERCELL(90.0F, 0.0F, Float.POSITIVE_INFINITY, true, true, true),
    SQUALL_LINE(78.0F, 0.0F, Float.POSITIVE_INFINITY, true, true, false),
    BOW_ECHO(80.0F, 0.0F, Float.POSITIVE_INFINITY, true, true, false),

    // ---- Wind events ----
    STRONG_WIND(25.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, false, false),
    DOWNBURST(75.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, true, false),
    MICROBURST(80.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, true, false),
    GUST_FRONT(55.0F, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, false, false),

    // ---- Non-mesocyclonic vortices ----
    DUST_DEVIL(30.0F, 20.0F, Float.POSITIVE_INFINITY, false, false, false),
    LANDSPOUT(60.0F, 0.0F, 30.0F, false, false, true),
    WATERSPOUT(60.0F, 5.0F, 35.0F, false, false, true),
    GUSTNADO(55.0F, 10.0F, 40.0F, false, false, true),

    // ---- Tornadoes (all require wind shear in addition to CAPE/instability) ----
    ROPE_TORNADO(86.0F, Float.NEGATIVE_INFINITY, 35.0F, false, true, true),
    CONE_TORNADO(90.0F, Float.NEGATIVE_INFINITY, 35.0F, false, true, true),
    WEDGE_TORNADO(95.0F, Float.NEGATIVE_INFINITY, 35.0F, false, true, true),
    MULTIPLE_VORTEX_TORNADO(97.0F, Float.NEGATIVE_INFINITY, 35.0F, false, true, true),

    // ---- Marine extremes (never selected by fromConditions; spawned by events) ----
    TSUNAMI(Float.MAX_VALUE, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, true, true, false),
    MAELSTROM(Float.MAX_VALUE, Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, false, true, false);

    /** Minimum cell instabilityIndex (0-100) required for this state. */
    public final float minInstability;
    /** Minimum air temperature in °C (NEGATIVE_INFINITY = unbounded). */
    public final float minTempC;
    /** Maximum air temperature in °C (POSITIVE_INFINITY = unbounded). */
    public final float maxTempC;
    public final boolean isPrecipitation;
    public final boolean isSevere;
    public final boolean isTornadic;

    /** Minimum 10 m wind speed (m/s) required for tornadic and vortex states. */
    public static final float TORNADO_MIN_WIND_SPEED = 10.0F;

    WeatherType(float minInstability, float minTempC, float maxTempC,
                boolean isPrecipitation, boolean isSevere, boolean isTornadic) {
        this.minInstability = minInstability;
        this.minTempC = minTempC;
        this.maxTempC = maxTempC;
        this.isPrecipitation = isPrecipitation;
        this.isSevere = isSevere;
        this.isTornadic = isTornadic;
    }

    /**
     * Chooses the MOST extreme (highest minInstability) eligible type for the
     * given cell state. TSUNAMI and MAELSTROM are excluded — they are event
     * driven only. Tornadic / vortex types additionally require sufficient
     * wind shear (approximated by wind speed), so they can never trigger from
     * instability (CAPE) alone. Waterspouts only form over water biomes.
     *
     * @param cell       current cell state (never null)
     * @param windSpeed  magnitude of cell wind vector in m/s
     * @param overWater  true when the anchor position is an ocean/river biome
     * @return the most extreme eligible type; CLEAR as fallback
     */
    public static WeatherType fromConditions(WeatherCell cell, float windSpeed, boolean overWater) {
        if (cell == null) return CLEAR;
        float inst = cell.instabilityIndex();
        float temp = cell.temperature();

        WeatherType best = CLEAR;
        // Iterate in declaration order and take the max minInstability, so the
        // result is order-independent and always the most extreme eligible type.
        for (WeatherType type : values()) {
            if (type == TSUNAMI || type == MAELSTROM) continue;
            if (inst < type.minInstability) continue;
            if (temp < type.minTempC || temp > type.maxTempC) continue;
            if (type == WATERSPOUT && !overWater) continue;
            if (type.isTornadic && windSpeed < TORNADO_MIN_WIND_SPEED) continue;
            if (type.minInstability > best.minInstability) best = type;
        }
        return best;
    }

    public String translationKey() {
        return "weathertype.atmosreal." + name().toLowerCase(java.util.Locale.ROOT);
    }
}
