package dev.atmosreal.engine;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.cloud.CloudSystem;
import dev.atmosreal.network.AtmosDataPacket;
import dev.atmosreal.network.ModNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Server-authoritative, per-loaded-chunk atmospheric simulation. */
public final class AtmosEngine {
    private static final int TICK_RATE = 20;
    private final Map<ChunkPos, WeatherCell> cells = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Long> lastAlert = new ConcurrentHashMap<>();
    private final Random random = new Random();
    private volatile CloudSystem cloudSystem;
    private long ticks;

    public void setCloudSystem(CloudSystem clouds) { this.cloudSystem = clouds; }
    public WeatherCell getCell(ChunkPos pos) { return cells.getOrDefault(pos, WeatherCell.DEFAULT); }
    public void updateCell(ChunkPos pos, WeatherCell cell) { cells.put(new ChunkPos(pos.x, pos.z), Objects.requireNonNull(cell).sanitized()); }
    public Map<ChunkPos, WeatherCell> snapshot() { return Map.copyOf(cells); }

    @SubscribeEvent public void onChunkLoad(ChunkEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel level) {
            ChunkPos pos = event.getChunk().getPos();
            WeatherCell stored = AtmosEngineData.getOrCreate(level).get(pos);
            cells.put(pos, stored == null ? WeatherCell.DEFAULT : stored);
        }
    }
    @SubscribeEvent public void onChunkUnload(ChunkEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) {
            ChunkPos pos = event.getChunk().getPos();
            WeatherCell cell = cells.remove(pos);
            if (cell != null) AtmosEngineData.getOrCreate(level).put(pos, cell);
        }
    }
    @SubscribeEvent public void onServerStarted(ServerStartedEvent event) { ticks = 0; }
    @SubscribeEvent public void onServerStopping(ServerStoppingEvent event) {
        for (ServerLevel level : event.getServer().getAllLevels()) {
            AtmosEngineData data = AtmosEngineData.getOrCreate(level);
            cells.forEach(data::put);
            data.setDirty();
        }
        cells.clear(); lastAlert.clear();
    }

    @SubscribeEvent public void onServerTick(ServerTickEvent.Post event) {
        if (++ticks % TICK_RATE != 0) return;
        MinecraftServer server = event.getServer();
        for (ServerLevel level : server.getAllLevels()) {
            Map<ChunkPos, WeatherCell> live = new HashMap<>();
            for (var entry : cells.entrySet()) if (level.getChunkSource().hasChunk(entry.getKey().x, entry.getKey().z)) live.put(entry.getKey(), entry.getValue());
            if (live.isEmpty()) continue;
            Map<ChunkPos, WeatherCell> next = new HashMap<>();
            for (var e : live.entrySet()) {
                ChunkPos p=e.getKey(); WeatherCell c=e.getValue();
                float[] avg=neighborAverage(p, live, c);
                float temp=c.temperature()+drift(avg[0]-c.temperature(), .025f)+noise(.10f);
                float hum=c.humidity()+drift(avg[1]-c.humidity(), .018f)+noise(.22f);
                float pressure=c.pressure()+drift(avg[2]-c.pressure(), .025f)+noise(.08f);
                float inst=c.instabilityIndex()+drift(avg[3]-c.instabilityIndex(), .012f)+noise(.18f);
                inst += Math.max(0, hum-72f)*.002f + Math.max(0, 1007f-pressure)*.008f - .015f;
                WeatherCell updated=new WeatherCell(temp,hum,pressure,c.windX()+noise(.12f),c.windZ()+noise(.12f),inst).sanitized();
                next.put(p, updated);
            }
            cells.putAll(next);
            AtmosEngineData data=AtmosEngineData.getOrCreate(level);
            next.forEach(data::put); data.setDirty();
            CloudSystem clouds=cloudSystem;
            if (clouds != null) clouds.update(level, next);
            for (var e: next.entrySet()) {
                WeatherCell c=e.getValue(); ChunkPos p=e.getKey();
                if (c.instabilityIndex() >= 70f && random.nextFloat() < c.precipitationChance()*.12f) {
                    if (clouds != null) clouds.precipitationTick(level,p,CloudSystem.getType(p),c);
                }
                if (c.instabilityIndex() > 85f) alertNearby(level,p,c);
                if (ticks % (TICK_RATE*3)==0) ModNetwork.sendToAllNear(level, new BlockPos(p.getMiddleBlockX(), level.getMinBuildHeight()+80, p.getMiddleBlockZ()), AtmosDataPacket.from(p,c));
            }
        }
    }
    private float[] neighborAverage(ChunkPos p, Map<ChunkPos,WeatherCell> source, WeatherCell self) {
        float t=0,h=0,pr=0,i=0; int n=0;
        for(int dx=-1;dx<=1;dx++) for(int dz=-1;dz<=1;dz++) { if(dx==0&&dz==0) continue; WeatherCell c=source.get(new ChunkPos(p.x+dx,p.z+dz)); if(c!=null){t+=c.temperature();h+=c.humidity();pr+=c.pressure();i+=c.instabilityIndex();n++;} }
        if(n==0) return new float[]{self.temperature(),self.humidity(),self.pressure(),self.instabilityIndex()};
        return new float[]{t/n,h/n,pr/n,i/n};
    }
    private float noise(float amplitude){return (random.nextFloat()*2f-1f)*amplitude;}
    private float drift(float d,float rate){return d*rate;}
    private void alertNearby(ServerLevel level, ChunkPos pos, WeatherCell c) {
        long now=ticks, previous=lastAlert.getOrDefault(pos, Long.MIN_VALUE/2);
        if(now-previous<20L*60L) return;
        lastAlert.put(pos,now); BlockPos center=new BlockPos(pos.getMiddleBlockX(), level.getMinBuildHeight()+80, pos.getMiddleBlockZ());
        for(ServerPlayer player:level.players()) if(player.blockPosition().distSqr(center)<(160*160)) {
            player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(Component.translatable("message.atmosreal.alert.severe")));
            player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(Component.translatable("message.atmosreal.alert.instability", Math.round(c.instabilityIndex()))));
        }
    }
}
