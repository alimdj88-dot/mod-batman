package dev.atmosreal.engine;

/**
 * WeatherCell — the atomic atmospheric state of a single chunk.
 * Immutable; every engine tick produces a new record instance, which keeps
 * cell evolution thread-safe and snapshot-friendly.
 *
 * Units:
 *   temperature     °C
 *   humidity        % (0–100)
 *   pressure        hPa (nominally 1013)
 *   windX / windZ   m/s along the X / Z axis
 *   instabilityIndex0–100, dimensionless storm/trouble index
 */
public record WeatherCell(
        float temperature,
        float humidity,
        float pressure,
        float windX,
        float windZ,
        float instabilityIndex) {

    // ------------------------------------------------------------------
    // Canonical bounds used by the engine and by serialization clamping.
    // ------------------------------------------------------------------
    public static final float HUMIDITY_MIN = 0.0F;
    public static final float HUMIDITY_MAX = 100.0F;
    public static final float PRESSURE_MIN = 950.0F;
    public static final float PRESSURE_MAX = 1050.0F;
    public static final float INSTABILITY_MIN = 0.0F;
    public static final float INSTABILITY_MAX = 100.0F;
    public static final float TEMP_MIN = -60.0F;
    public static final float TEMP_MAX = 60.0F;

    public static final WeatherCell DEFAULT =
            new WeatherCell(15.0F, 50.0F, 1013.0F, 0.0F, 0.0F, 15.0F);

    // ==================================================================
    // Constructors / helpers
    // ==================================================================

    /** Clamps every field into its physically valid range. */
    public WeatherCell sanitized() {
        return new WeatherCell(
                clamp(temperature, TEMP_MIN, TEMP_MAX),
                clamp(humidity, HUMIDITY_MIN, HUMIDITY_MAX),
                clamp(pressure, PRESSURE_MIN, PRESSURE_MAX),
                clamp(windX, -50.0F, 50.0F),
                clamp(windZ, -50.0F, 50.0F),
                clamp(instabilityIndex, INSTABILITY_MIN, INSTABILITY_MAX));
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    // ==================================================================
    // Derived meteorological predicates
    // ==================================================================

    /** A cell is stormy when instability is high and humidity is saturated. */
    public boolean isStormy() {
        return instabilityIndex >= 65.0F && humidity >= 85.0F;
    }

    /**
     * Thunder-ready: storm criteria met and instability steep enough for
     * charge separation inside the cloud.
     */
    public boolean isThunderReady() {
        return isStormy() && instabilityIndex >= 80.0F;
    }

    /**
     * Probability of precipitation (0.0–1.0) from humidity and instability.
     * Saturates near 1 when both are extreme.
     */
    public float precipitationChance() {
        float humidityFactor = Math.max(0.0F, (humidity - 40.0F) / 60.0F);
        float instabilityFactor = Math.max(0.0F, (instabilityIndex - 20.0F) / 80.0F);
        float chance = 0.55F * humidityFactor * humidityFactor
                     + 0.45F * instabilityFactor * instabilityFactor;
        return clamp(chance, 0.0F, 1.0F);
    }

    /** Magnitude of the horizontal wind vector, m/s. */
    public float windSpeed() {
        return (float) Math.sqrt(windX * windX + windZ * windZ);
    }

    /** Horizontal wind direction in radians (atan2 convention). */
    public float windDirection() {
        return (float) Math.atan2(windZ, windX);
    }

    /** Dew-point style estimate using Magnus approximation. */
    public float dewPoint() {
        double a = 17.62;
        double b = 243.12;
        float t = temperature;
        double gamma = Math.log(Math.max(humidity, 1.0F) / 100.0)
                + (a * t) / (b + t);
        return (float) ((b * gamma) / (a - gamma));
    }

    /** Maps this cell state to a {@link WeatherType} for gameplay systems. */
    public WeatherType getWeatherType() {
        if (isStormy()) return WeatherType.THUNDERSTORM;
        if (precipitationChance() > 0.5F) return WeatherType.MODERATE_RAIN;
        if (instabilityIndex >= 40.0F) return WeatherType.PARTLY_CLOUDY;
        return WeatherType.CLEAR;
    }

    // ==================================================================
    // Merging (used by diffusion steps in the engine)
    // ==================================================================

    /** Weighted average of two cells, weight w in [0..1] applied to this. */
    public WeatherCell lerp(WeatherCell other, float w) {
        w = clamp(w, 0.0F, 1.0F);
        return new WeatherCell(
                temperature + (other.temperature - temperature) * w,
                humidity + (other.humidity - humidity) * w,
                pressure + (other.pressure - pressure) * w,
                windX + (other.windX - windX) * w,
                windZ + (other.windZ - windZ) * w,
                instabilityIndex + (other.instabilityIndex - instabilityIndex) * w);
    }

    /** Adds a delta to instability without breaking range. */
    public WeatherCell withInstabilityDelta(float d) {
        float next = clamp(instabilityIndex + d, INSTABILITY_MIN, INSTABILITY_MAX);
        return new WeatherCell(temperature, humidity, pressure, windX, windZ, next);
    }

    @Override
    public String toString() {
        return "WeatherCell{T=" + temperature + "°C, RH=" + humidity
                + "%, P=" + pressure + "hPa, wind=(" + windX + "," + windZ
                + "), instability=" + instabilityIndex + "}";
    }
}
