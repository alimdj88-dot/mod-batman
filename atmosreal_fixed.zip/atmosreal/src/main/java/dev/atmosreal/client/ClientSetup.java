package dev.atmosreal.client;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.client.hud.WeatherHudOverlay;
import dev.atmosreal.client.screen.WeatherRadarScreen;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.minecraft.resources.ResourceLocation;

@EventBusSubscriber(modid = AtmosReal.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(ModKeyBindings.TOGGLE_HUD);
    }

    @SubscribeEvent
    public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAbove(
            VanillaGuiLayers.CHAT_PANEL,
            ResourceLocation.fromNamespaceAndPath(AtmosReal.MOD_ID, "weather_hud"),
            new WeatherHudOverlay()
        );
    }
}
