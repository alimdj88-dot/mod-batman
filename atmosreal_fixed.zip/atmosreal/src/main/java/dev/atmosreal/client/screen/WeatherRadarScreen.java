package dev.atmosreal.client.screen;

import dev.atmosreal.engine.WeatherCell;
import dev.atmosreal.engine.WeatherType;
import dev.atmosreal.network.ClientWeatherCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ChunkPos;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.Map;

@OnlyIn(Dist.CLIENT)
public class WeatherRadarScreen extends Screen {

    private static final int RADAR_SIZE  = 200;
    private static final int CELL_PX     = 4;  // pixels per chunk
    private static final int GRID_CELLS  = RADAR_SIZE / CELL_PX; // 50 cells

    public WeatherRadarScreen() {
        super(Component.translatable("screen.atmosreal.weather_radar"));
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partial) {
        this.renderBackground(gfx, mouseX, mouseY, partial);

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        int originX = (this.width  - RADAR_SIZE) / 2;
        int originY = (this.height - RADAR_SIZE) / 2;

        // Radar background
        gfx.fill(originX, originY, originX + RADAR_SIZE, originY + RADAR_SIZE, 0xFF0A1A0A);

        ChunkPos playerChunk = new ChunkPos(mc.player.blockPosition());
        int halfGrid = GRID_CELLS / 2;

        Map<ChunkPos, WeatherCell> snapshot = ClientWeatherCache.INSTANCE.snapshot();

        for (int dx = -halfGrid; dx < halfGrid; dx++) {
            for (int dz = -halfGrid; dz < halfGrid; dz++) {
                ChunkPos cp = new ChunkPos(playerChunk.x + dx, playerChunk.z + dz);
                WeatherCell cell = snapshot.get(cp);

                int color = cell != null
                    ? nexradColor(cell.getWeatherType(), cell.instabilityIndex())
                    : 0xFF0A1A0A;

                int px = originX + (dx + halfGrid) * CELL_PX;
                int py = originY + (dz + halfGrid) * CELL_PX;
                gfx.fill(px, py, px + CELL_PX, py + CELL_PX, color);
            }
        }

        // Player dot
        int cx = originX + halfGrid * CELL_PX;
        int cy = originY + halfGrid * CELL_PX;
        gfx.fill(cx, cy, cx + CELL_PX, cy + CELL_PX, 0xFFFFFFFF);

        // Title
        gfx.drawCenteredString(mc.font, this.title,
            this.width / 2, originY - 14, 0xFFE0E0E0);

        // Legend
        renderLegend(gfx, originX + RADAR_SIZE + 8, originY);

        super.render(gfx, mouseX, mouseY, partial);
    }

    /** NEXRAD-inspired palette: clear=black, light rain=green, heavy=yellow, severe=red/magenta */
    private static int nexradColor(WeatherType type, float instability) {
        return switch (type) {
            case CLEAR, PARTLY_CLOUDY -> 0xFF0A1A0A;
            case OVERCAST             -> 0xFF203020;
            case VIRGA, LIGHT_RAIN    -> 0xFF00AA00;
            case MODERATE_RAIN        -> 0xFF00DD00;
            case HEAVY_RAIN           -> 0xFFFFFF00;
            case TORRENTIAL_RAIN      -> 0xFFFF8800;
            case LIGHT_SNOW, SLEET    -> 0xFF88CCFF;
            case HEAVY_SNOW, BLIZZARD -> 0xFF4488FF;
            case FREEZING_RAIN        -> 0xFF00FFFF;
            case HAIL_GRAUPEL         -> 0xFFFF4400;
            case HAIL_GOLF            -> 0xFFFF0000;
            case HAIL_BASEBALL        -> 0xFFFF00FF;
            case THUNDERSTORM         -> 0xFFFF2200;
            case SEVERE_THUNDERSTORM  -> 0xFFCC0000;
            case SUPERCELL            -> 0xFFFF00AA;
            case SQUALL_LINE, BOW_ECHO -> 0xFFAA0044;
            case DUST_DEVIL, LANDSPOUT,
                 WATERSPOUT, GUSTNADO  -> 0xFFBB6600;
            case ROPE_TORNADO, CONE_TORNADO,
                 WEDGE_TORNADO, MULTIPLE_VORTEX_TORNADO -> 0xFFFF0088;
            case DOWNBURST, MICROBURST -> 0xFFFF6600;
            default -> instability > 50 ? 0xFFFF4444 : 0xFF204020;
        };
    }

    private static void renderLegend(GuiGraphics gfx, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        int[][] legend = {
            {0xFF00AA00, 0xFFE0FFE0},  // light rain
            {0xFFFFFF00, 0xFFFFFF00},  // heavy rain
            {0xFFFF8800, 0xFFFFAA44},  // torrential
            {0xFFFF0000, 0xFFFF4444},  // severe
            {0xFFFF00FF, 0xFFFF88FF},  // supercell
            {0xFFFF0088, 0xFFFF88CC},  // tornado
        };
        String[] labels = {"Light Rain","Heavy Rain","Torrential","Severe","Supercell","Tornado"};

        for (int i = 0; i < legend.length; i++) {
            gfx.fill(x, y + i * 14, x + 10, y + i * 14 + 10, legend[i][0]);
            gfx.drawString(mc.font, labels[i], x + 14, y + i * 14 + 1, legend[i][1]);
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
