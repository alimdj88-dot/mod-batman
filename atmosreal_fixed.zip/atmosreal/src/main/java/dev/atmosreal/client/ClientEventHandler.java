package dev.atmosreal.client;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.client.hud.WeatherHudOverlay;
import dev.atmosreal.client.screen.WeatherRadarScreen;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = AtmosReal.MOD_ID, value = Dist.CLIENT)
public class ClientEventHandler {

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        while (ModKeyBindings.TOGGLE_HUD.consumeClick()) {
            WeatherHudOverlay.toggle();
        }
    }
}
