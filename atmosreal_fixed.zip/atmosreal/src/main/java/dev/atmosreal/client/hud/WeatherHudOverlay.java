package dev.atmosreal.client.hud;

import dev.atmosreal.client.ModKeyBindings;
import dev.atmosreal.engine.WeatherCell;
import dev.atmosreal.network.ClientWeatherCache;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.world.level.ChunkPos;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class WeatherHudOverlay implements LayeredDraw.Layer {

    public static boolean visible = true;

    // Toggle on H key press (called from ClientSetup key handler)
    public static void toggle() {
        visible = !visible;
    }

    @Override
    public void render(GuiGraphics gfx, DeltaTracker delta) {
        if (!visible) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        ChunkPos chunk = new ChunkPos(mc.player.blockPosition());
        WeatherCell cell = ClientWeatherCache.INSTANCE.get(chunk);
        if (cell == null) return;

        int x = 4;
        int y = mc.getWindow().getGuiScaledHeight() - 68;
        int textColor = 0xFFE0E0E0;
        int shadowColor = 0x80000000;

        // Semi-transparent background
        gfx.fill(x - 2, y - 2,
                 x + 188, y + 62,
                 0x88000000);

        // Weather type header
        gfx.drawString(mc.font,
            "§e" + formatWeatherName(cell.getWeatherType().name()),
            x, y, textColor);

        // Row 1: temperature + humidity
        gfx.drawString(mc.font,
            String.format("§7Temp §f%.1f°C  §7Hum §f%.0f%%",
                cell.temperature(), cell.humidity() * 100f),
            x, y + 12, textColor);

        // Row 2: pressure + instability
        gfx.drawString(mc.font,
            String.format("§7Press §f%.1f hPa  §7CAPE §f%.0f",
                cell.pressure(), cell.instabilityIndex()),
            x, y + 24, textColor);

        // Row 3: wind speed + direction compass
        gfx.drawString(mc.font,
            String.format("§7Wind §f%.1f m/s §7%s",
                cell.windSpeed(), compassBearing(cell.windDirection())),
            x, y + 36, textColor);

        // Row 4: severity indicator
        if (cell.getWeatherType().isSevere()) {
            gfx.drawString(mc.font, "§c⚠ SEVERE WEATHER", x, y + 48, 0xFFFF4444);
        } else if (cell.getWeatherType().isTornadic()) {
            gfx.drawString(mc.font, "§c⚠ TORNADO WARNING", x, y + 48, 0xFFFF8800);
        }
    }

    private static String formatWeatherName(String raw) {
        return raw.replace('_', ' ');
    }

    private static String compassBearing(float degrees) {
        String[] dirs = {"N","NNE","NE","ENE","E","ESE","SE","SSE",
                         "S","SSW","SW","WSW","W","WNW","NW","NNW"};
        int idx = (int) Math.round(degrees / 22.5f) & 15;
        return dirs[idx];
    }
}
