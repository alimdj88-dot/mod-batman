package dev.atmosreal.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Reinforced shelter block. Players standing within 16 blocks of one
 * receive damage reduction from severe weather (see StormShelterCheck).
 * No block entity needed — StormShelterCheck queries the level directly.
 */
public class StormShelterBlock extends Block {

    public static final float PROTECTION_RADIUS = 16.0f;

    public StormShelterBlock(Properties props) {
        super(props);
    }
}
