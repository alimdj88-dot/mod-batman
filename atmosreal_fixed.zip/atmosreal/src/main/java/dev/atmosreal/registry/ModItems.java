package dev.atmosreal.registry;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.item.BarometerItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {

    public static final DeferredRegister.Items ITEMS =
        DeferredRegister.createItems(AtmosReal.MOD_ID);

    // ── Standalone items ────────────────────────────────────────────────────

    public static final DeferredItem<BarometerItem> BAROMETER =
        ITEMS.register("barometer",
            () -> new BarometerItem(new Item.Properties().stacksTo(1)));

    // ── Block items ─────────────────────────────────────────────────────────

    public static final DeferredItem<BlockItem> WEATHER_STATION =
        ITEMS.register("weather_station",
            () -> new BlockItem(ModBlocks.WEATHER_STATION.get(), new Item.Properties()));

    public static final DeferredItem<BlockItem> ANEMOMETER =
        ITEMS.register("anemometer",
            () -> new BlockItem(ModBlocks.ANEMOMETER.get(), new Item.Properties()));

    public static final DeferredItem<BlockItem> STORM_SHELTER =
        ITEMS.register("storm_shelter",
            () -> new BlockItem(ModBlocks.STORM_SHELTER.get(), new Item.Properties()));
}
