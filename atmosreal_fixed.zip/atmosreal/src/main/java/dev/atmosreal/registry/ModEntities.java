package dev.atmosreal.registry;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.tornado.TornadoEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Entity registry for AtmosReal. Register on the MOD event bus:
 * {@code ModEntities.ENTITY_TYPES.register(modEventBus);}
 */
public final class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, AtmosReal.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<TornadoEntity>> TORNADO =
            ENTITY_TYPES.register("tornado",
                    () -> EntityType.Builder.<TornadoEntity>of(TornadoEntity::new, MobCategory.MISC)
                            .sized(6.0F, 24.0F) // wide funnel footprint, tall hit box
                            .clientTrackingRange(16)
                            .updateInterval(20)
                            .noSummon() // spawned only by TornadoSimulator; remove .noSummon() to allow /summon
                            .build("tornado"));

    /** Wires the register onto the mod event bus. */
    public static void register(IEventBus modEventBus) {
        ENTITY_TYPES.register(modEventBus);
    }

    private ModEntities() {}
}
