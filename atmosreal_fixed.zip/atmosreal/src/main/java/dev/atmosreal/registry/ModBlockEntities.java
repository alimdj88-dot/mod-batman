package dev.atmosreal.registry;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.blockentity.AnemometerBlockEntity;
import dev.atmosreal.blockentity.WeatherStationBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
        DeferredRegister.create(net.minecraft.core.registries.Registries.BLOCK_ENTITY_TYPE,
            AtmosReal.MOD_ID);

    public static final Supplier<BlockEntityType<WeatherStationBlockEntity>> WEATHER_STATION =
        BLOCK_ENTITIES.register("weather_station",
            () -> BlockEntityType.Builder
                .of(WeatherStationBlockEntity::new,
                    ModBlocks.WEATHER_STATION.get())
                .build(null));

    public static final Supplier<BlockEntityType<AnemometerBlockEntity>> ANEMOMETER =
        BLOCK_ENTITIES.register("anemometer",
            () -> BlockEntityType.Builder
                .of(AnemometerBlockEntity::new,
                    ModBlocks.ANEMOMETER.get())
                .build(null));
}
