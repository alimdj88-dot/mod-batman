package dev.atmosreal.registry;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.block.AnemometerBlock;
import dev.atmosreal.block.StormShelterBlock;
import dev.atmosreal.block.WeatherStationBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {

    public static final DeferredRegister.Blocks BLOCKS =
        DeferredRegister.createBlocks(AtmosReal.MOD_ID);

    public static final DeferredBlock<WeatherStationBlock> WEATHER_STATION =
        BLOCKS.register("weather_station", () -> new WeatherStationBlock(
            BlockBehaviour.Properties.of()
                .strength(3.0f, 6.0f)
                .sound(SoundType.METAL)
                .requiresCorrectToolForDrops()
                .noOcclusion()
        ));

    public static final DeferredBlock<AnemometerBlock> ANEMOMETER =
        BLOCKS.register("anemometer", () -> new AnemometerBlock(
            BlockBehaviour.Properties.of()
                .strength(2.0f, 4.0f)
                .sound(SoundType.METAL)
                .requiresCorrectToolForDrops()
                .noOcclusion()
        ));

    public static final DeferredBlock<StormShelterBlock> STORM_SHELTER =
        BLOCKS.register("storm_shelter", () -> new StormShelterBlock(
            BlockBehaviour.Properties.of()
                .strength(50.0f, 1200.0f)
                .sound(SoundType.DEEPSLATE)
                .requiresCorrectToolForDrops()
        ));
}
