package dev.atmosreal.weather;

import dev.atmosreal.AtmosReal;
import dev.atmosreal.config.AtmosRealConfig;
import dev.atmosreal.engine.AtmosEngine;
import dev.atmosreal.engine.WeatherCell;
import dev.atmosreal.engine.WeatherType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * LightningSystem — spawns fractal lightning for thunderstorm-type weather
 * cells, then applies ground impact effects (fire, entity damage, creeper
 * charging, fulgurite glass) scaled by {@link AtmosRealConfig}.
 */
public final class LightningSystem {

    /** Thunderstorm weather types eligible for lightning strikes. */
    private static final java.util.Set<WeatherType> THUNDER_TYPES = java.util.Set.of(
            WeatherType.THUNDERSTORM,
            WeatherType.SEVERE_THUNDERSTORM,
            WeatherType.SUPERCELL,
            WeatherType.SQUALL_LINE,
            WeatherType.BOW_ECHO);

    private static final int TICK_RATE = 20; // once per second
    private final Random random = new Random();
    private long ticks;

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        if (!AtmosRealConfig.lightningEnabled) return;
        if (++ticks % TICK_RATE != 0) return;
        AtmosEngine engine = AtmosReal.getEngine();
        if (engine == null) return;

        for (ServerLevel level : event.getServer().getAllLevels()) {
            Map<ChunkPos, WeatherCell> live = new HashMap<>();
            for (Map.Entry<ChunkPos, WeatherCell> e : engine.snapshot().entrySet()) {
                if (level.getChunkSource().hasChunk(e.getKey().x, e.getKey().z)) {
                    live.put(e.getKey(), e.getValue());
                }
            }
            for (Map.Entry<ChunkPos, WeatherCell> e : live.entrySet()) {
                tickCell(level, e.getKey(), e.getValue());
            }
        }
    }

    private void tickCell(ServerLevel level, ChunkPos pos, WeatherCell cell) {
        WeatherType type = WeatherType.fromConditions(cell, cell.windSpeed(), false);
        if (!THUNDER_TYPES.contains(type)) return;

        // Strike probability per second grows with instability (80..100).
        float instability = cell.instabilityIndex();
        double baseChance = Math.max(0.0, (instability - 70.0) / 100.0) * 0.10; // up to ~3%/s at 100
        double chance = baseChance * AtmosRealConfig.lightningRateMultiplier;
        if (random.nextDouble() >= chance) return;

        int x = pos.getMinBlockX() + random.nextInt(16);
        int z = pos.getMinBlockZ() + random.nextInt(16);
        int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, x, z);
        BlockPos strike = new BlockPos(x, y, z);

        strike(level, Vec3.atLowerCornerOf(strike));
    }

    // ==================================================================
    // Fractal bolt generation + impact
    // ==================================================================

    /** A polyline segment of the bolt (world space, y measured from ground). */
    public record BoltSegment(double x1, double y1, double z1, double x2, double y2, double z2) {}

    /**
     * Generates a fractal lightning path from cloud height (~ y+40) down to
     * {@code ground} using midpoint displacement, plus short side branches.
     */
    public static List<List<Vec3>> generateFractalBolt(Random random, Vec3 ground, int depth, float jag) {
        List<Vec3> main = new ArrayList<>();
        main.add(ground.add(0, 40, 0));
        main.add(ground);
        displace(random, main, 0, main.size() - 1, depth, jag);
        List<List<Vec3>> paths = new ArrayList<>();
        paths.add(main);

        // 1-3 fractal branches from random points on the main channel.
        int branches = 1 + random.nextInt(3);
        for (int b = 0; b < branches && main.size() > 4; b++) {
            int idx = 1 + random.nextInt(main.size() - 2);
            Vec3 start = main.get(idx);
            Vec3 dir = main.get(idx + 1).subtract(main.get(idx - 1)).normalize();
            Vec3 side = new Vec3(-dir.z, 0, dir.x).scale((random.nextDouble() - 0.5) * 6.0);
            List<Vec3> branch = new ArrayList<>();
            branch.add(start);
            Vec3 end = start.add(side).add(0, -(4 + random.nextDouble() * 10), 0);
            branch.add(end);
            displace(random, branch, 0, branch.size() - 1, Math.max(1, depth - 2), jag);
            paths.add(branch);
        }
        return paths;
    }

    /** Recursive midpoint displacement over the polyline indices [a,b]. */
    private static void displace(Random random, List<Vec3> pts, int a, int b, int depth, float jag) {
        if (depth <= 0 || b - a < 2) return;
        Vec3 p1 = pts.get(a), p2 = pts.get(b);
        Vec3 mid = p1.add(p2).scale(0.5);
        Vec3 jitter = new Vec3(
                (random.nextDouble() - 0.5) * jag,
                (random.nextDouble() - 0.5) * jag * 0.25,
                (random.nextDouble() - 0.5) * jag);
        pts.add(a + 1, mid.add(jitter));
        displace(random, pts, a, a + 1, depth - 1, jag * 0.55f);
        displace(random, pts, a + 1, b, depth - 1, jag * 0.55f);
    }

    /** Spawns a real lightning bolt entity and applies impact effects. */
    public void strike(ServerLevel level, Vec3 ground) {
        BlockPos pos = BlockPos.containing(ground);

        // Visual/audible bolt via vanilla entity (also ignites per vanilla rules).
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(ground.x, ground.y, ground.z);
            bolt.setVisualOnly(false);
            level.addFreshEntity(bolt);
        }

        // Fractal path is used for particle FX along the channel + branches.
        List<List<Vec3>> paths = generateFractalBolt(random, ground, 4, 5.0f);
        for (List<Vec3> path : paths) {
            for (int i = 0; i < path.size() - 1; i++) {
                Vec3 a = path.get(i), b = path.get(i + 1);
                int steps = Math.max(1, (int) (a.distanceTo(b) * 2));
                for (int s = 0; s <= steps; s++) {
                    Vec3 p = a.lerp(b, s / (double) steps);
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0.0);
                }
            }
        }
        level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER, 2.0F, 1.0F);

        // ---- Fire on impact (respects config) ----
        if (random.nextDouble() < 0.3) { // fireProbability from the TOML tuning table
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos fp = pos.offset(dx, 0, dz);
                    if (random.nextFloat() < 0.4F) {
                        BlockState below = level.getBlockState(fp.below());
                        if (below.isAir()) continue;
                        if (level.getBlockState(fp).isAir() && BaseFireBlock.canBePlacedAt(level, fp, net.minecraft.core.Direction.UP)) {
                            level.setBlockAndUpdate(fp, BaseFireBlock.getState(level, fp));
                        }
                    }
                }
            }
        }

        // ---- Fulgurite (sand -> glass) ----
        if (random.nextDouble() < AtmosRealConfig.fulguriteChance) {
            BlockPos below = pos.below();
            if (level.getBlockState(below).is(Blocks.SAND)) {
                level.setBlockAndUpdate(below, Blocks.GLASS.defaultBlockState());
            }
        }

        // ---- Entity damage in radius (scaled by lightning damage multiplier) ----
        double damage = 6.0 * AtmosRealConfig.lightningRateMultiplier; // multiplier doubles as damage scale
        AABB box = new AABB(pos).inflate(4.0);
        for (LivingEntity living : level.getEntitiesOfClass(LivingEntity.class, box)) {
            living.hurt(level.damageSources().lightningBolt(), (float) damage);
        }

        // ---- Charge creepers into charged creepers ----
        for (var creeper : level.getEntitiesOfClass(net.minecraft.world.entity.monster.Creeper.class, box)) {
            creeper.thunderHit(level, bolt != null ? bolt : new LightningBolt(EntityType.LIGHTNING_BOLT, level));
        }
    }
}
