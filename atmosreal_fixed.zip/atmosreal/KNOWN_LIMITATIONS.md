# Known Limitations — AtmosReal 1.0.0

## Compilation
- Requires Java 21, Gradle 8.8+, and NeoForge MDK to build
- Sandbox environment (no Java/Gradle/internet) cannot produce a JAR

## Missing Visual Systems
- Volumetric cloud rendering (CloudSystem spawns server-side particles only)
- No GLSL shaders or resource pack textures included
- No block/item model JSON files

## Missing Gameplay Systems
- No localized precipitation (rain/snow/hail per-chunk density)
- No weather front simulation
- No flood mechanics
- No seasonal cycle integration
- No weather forecast block/item

## Testing
- No unit or integration tests (`src/test` absent)
- No CI configuration
