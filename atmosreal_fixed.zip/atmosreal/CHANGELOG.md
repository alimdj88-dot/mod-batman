# AtmosReal Changelog

## [1.0.0] - 2026-10-21
### Fixed
- Renamed `AtmosphereEngine` references to `AtmosEngine` across 4 files (BarometerItem, WindSystem, AnemometerBlockEntity, WeatherStationBlockEntity)
- Added missing `atmosreal.mixins.json` (referenced in neoforge.mods.toml but absent)
- Added missing `pack.mcmeta`
- Added empty `accesstransformer.cfg` (referenced in build.gradle)
- Added Gradle wrapper properties

### Known Limitations
- No volumetric cloud rendering (CloudSystem is server-side particle only)
- No WeatherRadarScreen advanced rendering
- No localized precipitation/fronts/flood/season system
- Sandbox JAR compilation not possible without Java/Gradle toolchain
